#!/bin/bash

set -e

echo "🔧 Recreating 'monitoring' namespace..."
kubectl create namespace monitoring --dry-run=client -o yaml | kubectl apply -f -

echo "🔄 Patching existing PersistentVolumes to remove claimRef..."
kubectl patch pv grafana-pv -p '{"spec":{"claimRef": null}}'
kubectl patch pv alertmanager-pv -p '{"spec":{"claimRef": null}}'
kubectl patch pv prometheus-pv -p '{"spec":{"claimRef": null}}'

echo "📦 Recreating PVCs in 'monitoring' namespace..."

cat <<EOF | kubectl apply -f -
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: grafana-pvc
  namespace: monitoring
spec:
  storageClassName: manual
  accessModes:
    - ReadWriteOnce
  resources:
    requests:
      storage: 5Gi
---
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: alertmanager-kps-pvc
  namespace: monitoring
spec:
  storageClassName: manual
  accessModes:
    - ReadWriteOnce
  resources:
    requests:
      storage: 2Gi
---
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: prometheus-kps-pvc
  namespace: monitoring
spec:
  storageClassName: manual
  accessModes:
    - ReadWriteOnce
  resources:
    requests:
      storage: 10Gi
EOF

echo "✅ PVCs re-created and bound to retained PVs."